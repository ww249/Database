﻿namespace 图书馆系统
{
    partial class MainForm_user
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.消息提醒 = new System.Windows.Forms.Button();
            this.借还业务 = new System.Windows.Forms.Button();
            this.预约业务 = new System.Windows.Forms.Button();
            this.信息修改 = new System.Windows.Forms.Button();
            this.意见反馈 = new System.Windows.Forms.Button();
            this.图书一览 = new System.Windows.Forms.Button();
            this.zs2 = new System.Windows.Forms.Button();
            this.zs1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tushuyilan = new System.Windows.Forms.GroupBox();
            this.dataGridView查看图书 = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bnum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xinxigenggai = new System.Windows.Forms.GroupBox();
            this.label6yonghu = new System.Windows.Forms.Label();
            this.button4qq修改 = new System.Windows.Forms.Button();
            this.button3年龄修改 = new System.Windows.Forms.Button();
            this.button2性别修改 = new System.Windows.Forms.Button();
            this.button1密码修改 = new System.Windows.Forms.Button();
            this.textBox5qq = new System.Windows.Forms.TextBox();
            this.textBox4nianling = new System.Windows.Forms.TextBox();
            this.textBox3xingbie = new System.Windows.Forms.TextBox();
            this.textBoxmima = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.yuyueyewu = new System.Windows.Forms.GroupBox();
            this.图书预约 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.button1预约查询 = new System.Windows.Forms.Button();
            this.textBox4预约书名 = new System.Windows.Forms.TextBox();
            this.textBox1预约书号 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dataGridView1预约显示 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.书名 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label8预约书号 = new System.Windows.Forms.Label();
            this.button4预约按钮 = new System.Windows.Forms.Button();
            this.textBox3预约辅助 = new System.Windows.Forms.TextBox();
            this.textBox2预约辅助 = new System.Windows.Forms.TextBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.label1预约用户 = new System.Windows.Forms.Label();
            this.dataGridView2预约表 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yijianfankui = new System.Windows.Forms.GroupBox();
            this.textBox1留言 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.返回留言 = new System.Windows.Forms.Button();
            this.button2精选留言 = new System.Windows.Forms.Button();
            this.dataGridView2精选留言 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button6联系我们 = new System.Windows.Forms.Button();
            this.button2liuyan = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox2特征码 = new System.Windows.Forms.TextBox();
            this.label3特征码 = new System.Windows.Forms.Label();
            this.label1留言 = new System.Windows.Forms.Label();
            this.xiaoxitixing = new System.Windows.Forms.GroupBox();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.dataGridView1siliao = new System.Windows.Forms.DataGridView();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.dataGridView1qb = new System.Windows.Forms.DataGridView();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.button1fasong = new System.Windows.Forms.Button();
            this.textBox2id = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.nr = new System.Windows.Forms.Label();
            this.textBox1message = new System.Windows.Forms.TextBox();
            this.jiehuanyewu = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.zs3 = new System.Windows.Forms.Button();
            this.dataGridView1借书表 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button5查询 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox7书名 = new System.Windows.Forms.TextBox();
            this.textBox8书号 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox3辅助 = new System.Windows.Forms.TextBox();
            this.textBox2辅助1 = new System.Windows.Forms.TextBox();
            this.label1用户 = new System.Windows.Forms.Label();
            this.button1借书按钮 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.textBox1书号 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label22用户 = new System.Windows.Forms.Label();
            this.button2还书按钮 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dataGridView3借阅信息 = new System.Windows.Forms.DataGridView();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dataGridView2还书信息 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timerxiaoxi = new System.Windows.Forms.Timer(this.components);
            this.flaglabel1 = new System.Windows.Forms.Label();
            this.rereadtimer1 = new System.Windows.Forms.Timer(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.tushuyilan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView查看图书)).BeginInit();
            this.xinxigenggai.SuspendLayout();
            this.yuyueyewu.SuspendLayout();
            this.图书预约.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1预约显示)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2预约表)).BeginInit();
            this.yijianfankui.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2精选留言)).BeginInit();
            this.xiaoxitixing.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1siliao)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1qb)).BeginInit();
            this.tabPage9.SuspendLayout();
            this.jiehuanyewu.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1借书表)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3借阅信息)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2还书信息)).BeginInit();
            this.SuspendLayout();
            // 
            // 消息提醒
            // 
            this.消息提醒.Location = new System.Drawing.Point(761, 40);
            this.消息提醒.Name = "消息提醒";
            this.消息提醒.Size = new System.Drawing.Size(155, 45);
            this.消息提醒.TabIndex = 20;
            this.消息提醒.Text = "消息提醒";
            this.消息提醒.UseVisualStyleBackColor = true;
            this.消息提醒.Click += new System.EventHandler(this.消息提醒_Click);
            // 
            // 借还业务
            // 
            this.借还业务.Location = new System.Drawing.Point(143, 40);
            this.借还业务.Name = "借还业务";
            this.借还业务.Size = new System.Drawing.Size(155, 45);
            this.借还业务.TabIndex = 19;
            this.借还业务.Text = "借还业务";
            this.借还业务.UseVisualStyleBackColor = true;
            this.借还业务.Click += new System.EventHandler(this.借还业务_Click);
            // 
            // 预约业务
            // 
            this.预约业务.Location = new System.Drawing.Point(298, 40);
            this.预约业务.Name = "预约业务";
            this.预约业务.Size = new System.Drawing.Size(155, 45);
            this.预约业务.TabIndex = 18;
            this.预约业务.Text = "预约业务";
            this.预约业务.UseVisualStyleBackColor = true;
            this.预约业务.Click += new System.EventHandler(this.预约业务_Click);
            // 
            // 信息修改
            // 
            this.信息修改.Location = new System.Drawing.Point(453, 40);
            this.信息修改.Name = "信息修改";
            this.信息修改.Size = new System.Drawing.Size(155, 45);
            this.信息修改.TabIndex = 17;
            this.信息修改.Text = "信息更改";
            this.信息修改.UseVisualStyleBackColor = true;
            this.信息修改.Click += new System.EventHandler(this.信息修改_Click);
            // 
            // 意见反馈
            // 
            this.意见反馈.Location = new System.Drawing.Point(607, 40);
            this.意见反馈.Name = "意见反馈";
            this.意见反馈.Size = new System.Drawing.Size(155, 45);
            this.意见反馈.TabIndex = 16;
            this.意见反馈.Text = "意见反馈";
            this.意见反馈.UseVisualStyleBackColor = true;
            this.意见反馈.Click += new System.EventHandler(this.意见反馈_Click);
            // 
            // 图书一览
            // 
            this.图书一览.Location = new System.Drawing.Point(-14, 40);
            this.图书一览.Name = "图书一览";
            this.图书一览.Size = new System.Drawing.Size(157, 45);
            this.图书一览.TabIndex = 15;
            this.图书一览.Text = "图书一览";
            this.图书一览.UseVisualStyleBackColor = true;
            this.图书一览.Click += new System.EventHandler(this.图书一览_Click);
            // 
            // zs2
            // 
            this.zs2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.zs2.Enabled = false;
            this.zs2.Location = new System.Drawing.Point(-60, 82);
            this.zs2.Name = "zs2";
            this.zs2.Size = new System.Drawing.Size(989, 11);
            this.zs2.TabIndex = 14;
            this.zs2.UseVisualStyleBackColor = false;
            // 
            // zs1
            // 
            this.zs1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.zs1.Enabled = false;
            this.zs1.Location = new System.Drawing.Point(-90, 32);
            this.zs1.Name = "zs1";
            this.zs1.Size = new System.Drawing.Size(1019, 10);
            this.zs1.TabIndex = 13;
            this.zs1.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Info;
            this.label1.Font = new System.Drawing.Font("楷体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(880, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1499, 20);
            this.label1.TabIndex = 11;
            this.label1.Text = "欢迎您使用图书管理系统用户端！ 如需帮助可通过用户端联系我们与我们取得联系，若您对本产品有意见或建议，请通过用户端意见反馈向我们提出！有疑问可联系作者";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Info;
            this.label2.Font = new System.Drawing.Font("宋体", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.SystemColors.Info;
            this.label2.Location = new System.Drawing.Point(-4, -7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(2505, 43);
            this.label2.TabIndex = 12;
            this.label2.Text = "                                                                                 " +
    "                                ";
            // 
            // tushuyilan
            // 
            this.tushuyilan.Controls.Add(this.dataGridView查看图书);
            this.tushuyilan.Location = new System.Drawing.Point(4, 90);
            this.tushuyilan.Name = "tushuyilan";
            this.tushuyilan.Size = new System.Drawing.Size(903, 409);
            this.tushuyilan.TabIndex = 21;
            this.tushuyilan.TabStop = false;
            // 
            // dataGridView查看图书
            // 
            this.dataGridView查看图书.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView查看图书.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.bname,
            this.bnum});
            this.dataGridView查看图书.Location = new System.Drawing.Point(0, 9);
            this.dataGridView查看图书.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView查看图书.Name = "dataGridView查看图书";
            this.dataGridView查看图书.RowTemplate.Height = 23;
            this.dataGridView查看图书.Size = new System.Drawing.Size(903, 400);
            this.dataGridView查看图书.TabIndex = 6;
            // 
            // id
            // 
            this.id.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.id.DataPropertyName = "id";
            this.id.HeaderText = "书号";
            this.id.Name = "id";
            // 
            // bname
            // 
            this.bname.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.bname.DataPropertyName = "bname";
            this.bname.HeaderText = "书名";
            this.bname.Name = "bname";
            // 
            // bnum
            // 
            this.bnum.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.bnum.DataPropertyName = "bnum";
            this.bnum.HeaderText = "数量";
            this.bnum.Name = "bnum";
            // 
            // xinxigenggai
            // 
            this.xinxigenggai.Controls.Add(this.label6yonghu);
            this.xinxigenggai.Controls.Add(this.button4qq修改);
            this.xinxigenggai.Controls.Add(this.button3年龄修改);
            this.xinxigenggai.Controls.Add(this.button2性别修改);
            this.xinxigenggai.Controls.Add(this.button1密码修改);
            this.xinxigenggai.Controls.Add(this.textBox5qq);
            this.xinxigenggai.Controls.Add(this.textBox4nianling);
            this.xinxigenggai.Controls.Add(this.textBox3xingbie);
            this.xinxigenggai.Controls.Add(this.textBoxmima);
            this.xinxigenggai.Controls.Add(this.label5);
            this.xinxigenggai.Controls.Add(this.label4);
            this.xinxigenggai.Controls.Add(this.label3);
            this.xinxigenggai.Controls.Add(this.label6);
            this.xinxigenggai.Controls.Add(this.label7);
            this.xinxigenggai.Location = new System.Drawing.Point(4, 90);
            this.xinxigenggai.Name = "xinxigenggai";
            this.xinxigenggai.Size = new System.Drawing.Size(903, 409);
            this.xinxigenggai.TabIndex = 22;
            this.xinxigenggai.TabStop = false;
            // 
            // label6yonghu
            // 
            this.label6yonghu.AutoSize = true;
            this.label6yonghu.Font = new System.Drawing.Font("楷体", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6yonghu.Location = new System.Drawing.Point(413, 66);
            this.label6yonghu.Name = "label6yonghu";
            this.label6yonghu.Size = new System.Drawing.Size(102, 28);
            this.label6yonghu.TabIndex = 45;
            this.label6yonghu.Text = "label6";
            // 
            // button4qq修改
            // 
            this.button4qq修改.Font = new System.Drawing.Font("楷体", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button4qq修改.Location = new System.Drawing.Point(712, 298);
            this.button4qq修改.Name = "button4qq修改";
            this.button4qq修改.Size = new System.Drawing.Size(93, 37);
            this.button4qq修改.TabIndex = 43;
            this.button4qq修改.Text = "修改";
            this.button4qq修改.UseVisualStyleBackColor = true;
            this.button4qq修改.Click += new System.EventHandler(this.button4qq修改_Click);
            // 
            // button3年龄修改
            // 
            this.button3年龄修改.Font = new System.Drawing.Font("楷体", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button3年龄修改.Location = new System.Drawing.Point(712, 238);
            this.button3年龄修改.Name = "button3年龄修改";
            this.button3年龄修改.Size = new System.Drawing.Size(93, 38);
            this.button3年龄修改.TabIndex = 42;
            this.button3年龄修改.Text = "修改";
            this.button3年龄修改.UseVisualStyleBackColor = true;
            this.button3年龄修改.Click += new System.EventHandler(this.button3年龄修改_Click);
            // 
            // button2性别修改
            // 
            this.button2性别修改.Font = new System.Drawing.Font("楷体", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2性别修改.Location = new System.Drawing.Point(712, 181);
            this.button2性别修改.Name = "button2性别修改";
            this.button2性别修改.Size = new System.Drawing.Size(93, 38);
            this.button2性别修改.TabIndex = 41;
            this.button2性别修改.Text = "修改";
            this.button2性别修改.UseVisualStyleBackColor = true;
            this.button2性别修改.Click += new System.EventHandler(this.button2性别修改_Click);
            // 
            // button1密码修改
            // 
            this.button1密码修改.Font = new System.Drawing.Font("楷体", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1密码修改.Location = new System.Drawing.Point(712, 124);
            this.button1密码修改.Name = "button1密码修改";
            this.button1密码修改.Size = new System.Drawing.Size(93, 40);
            this.button1密码修改.TabIndex = 40;
            this.button1密码修改.Text = "修改";
            this.button1密码修改.UseVisualStyleBackColor = true;
            this.button1密码修改.Click += new System.EventHandler(this.button1密码修改_Click);
            // 
            // textBox5qq
            // 
            this.textBox5qq.Font = new System.Drawing.Font("楷体", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox5qq.Location = new System.Drawing.Point(375, 286);
            this.textBox5qq.Name = "textBox5qq";
            this.textBox5qq.Size = new System.Drawing.Size(210, 38);
            this.textBox5qq.TabIndex = 39;
            this.textBox5qq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4nianling
            // 
            this.textBox4nianling.Font = new System.Drawing.Font("楷体", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox4nianling.Location = new System.Drawing.Point(375, 227);
            this.textBox4nianling.Name = "textBox4nianling";
            this.textBox4nianling.Size = new System.Drawing.Size(210, 38);
            this.textBox4nianling.TabIndex = 38;
            this.textBox4nianling.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3xingbie
            // 
            this.textBox3xingbie.Font = new System.Drawing.Font("楷体", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox3xingbie.Location = new System.Drawing.Point(375, 170);
            this.textBox3xingbie.Name = "textBox3xingbie";
            this.textBox3xingbie.Size = new System.Drawing.Size(210, 38);
            this.textBox3xingbie.TabIndex = 37;
            this.textBox3xingbie.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxmima
            // 
            this.textBoxmima.Font = new System.Drawing.Font("楷体", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBoxmima.Location = new System.Drawing.Point(375, 117);
            this.textBoxmima.Name = "textBoxmima";
            this.textBoxmima.Size = new System.Drawing.Size(210, 38);
            this.textBoxmima.TabIndex = 36;
            this.textBoxmima.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("楷体", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(62, 300);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 28);
            this.label5.TabIndex = 35;
            this.label5.Text = "QQ：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("楷体", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(62, 241);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 28);
            this.label4.TabIndex = 34;
            this.label4.Text = "年龄：";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("楷体", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(62, 184);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 28);
            this.label3.TabIndex = 33;
            this.label3.Text = "性别：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("楷体", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(62, 131);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 28);
            this.label6.TabIndex = 32;
            this.label6.Text = "密码：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("楷体", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(62, 76);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(143, 28);
            this.label7.TabIndex = 31;
            this.label7.Text = "用户名*：";
            // 
            // yuyueyewu
            // 
            this.yuyueyewu.Controls.Add(this.图书预约);
            this.yuyueyewu.Location = new System.Drawing.Point(4, 90);
            this.yuyueyewu.Name = "yuyueyewu";
            this.yuyueyewu.Size = new System.Drawing.Size(903, 409);
            this.yuyueyewu.TabIndex = 23;
            this.yuyueyewu.TabStop = false;
            // 
            // 图书预约
            // 
            this.图书预约.Controls.Add(this.tabPage6);
            this.图书预约.Controls.Add(this.tabPage5);
            this.图书预约.Location = new System.Drawing.Point(0, 2);
            this.图书预约.Margin = new System.Windows.Forms.Padding(4);
            this.图书预约.Name = "图书预约";
            this.图书预约.SelectedIndex = 0;
            this.图书预约.Size = new System.Drawing.Size(903, 407);
            this.图书预约.TabIndex = 12;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.button1预约查询);
            this.tabPage6.Controls.Add(this.textBox4预约书名);
            this.tabPage6.Controls.Add(this.textBox1预约书号);
            this.tabPage6.Controls.Add(this.label9);
            this.tabPage6.Controls.Add(this.dataGridView1预约显示);
            this.tabPage6.Controls.Add(this.label8预约书号);
            this.tabPage6.Controls.Add(this.button4预约按钮);
            this.tabPage6.Controls.Add(this.textBox3预约辅助);
            this.tabPage6.Controls.Add(this.textBox2预约辅助);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage6.Size = new System.Drawing.Size(895, 378);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "图书预约";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // button1预约查询
            // 
            this.button1预约查询.Location = new System.Drawing.Point(803, 17);
            this.button1预约查询.Name = "button1预约查询";
            this.button1预约查询.Size = new System.Drawing.Size(65, 33);
            this.button1预约查询.TabIndex = 12;
            this.button1预约查询.Text = "查询";
            this.button1预约查询.UseVisualStyleBackColor = true;
            this.button1预约查询.Click += new System.EventHandler(this.button1预约查询_Click);
            // 
            // textBox4预约书名
            // 
            this.textBox4预约书名.Font = new System.Drawing.Font("楷体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox4预约书名.Location = new System.Drawing.Point(535, 17);
            this.textBox4预约书名.Name = "textBox4预约书名";
            this.textBox4预约书名.Size = new System.Drawing.Size(245, 34);
            this.textBox4预约书名.TabIndex = 11;
            // 
            // textBox1预约书号
            // 
            this.textBox1预约书号.Font = new System.Drawing.Font("楷体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox1预约书号.Location = new System.Drawing.Point(135, 17);
            this.textBox1预约书号.Name = "textBox1预约书号";
            this.textBox1预约书号.Size = new System.Drawing.Size(286, 34);
            this.textBox1预约书号.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("楷体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.Location = new System.Drawing.Point(441, 20);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 24);
            this.label9.TabIndex = 9;
            this.label9.Text = "书名：";
            // 
            // dataGridView1预约显示
            // 
            this.dataGridView1预约显示.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1预约显示.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.书名,
            this.dataGridViewTextBoxColumn6});
            this.dataGridView1预约显示.Location = new System.Drawing.Point(0, 58);
            this.dataGridView1预约显示.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1预约显示.Name = "dataGridView1预约显示";
            this.dataGridView1预约显示.RowTemplate.Height = 23;
            this.dataGridView1预约显示.Size = new System.Drawing.Size(899, 259);
            this.dataGridView1预约显示.TabIndex = 3;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn5.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn5.HeaderText = "书号";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // 书名
            // 
            this.书名.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.书名.DataPropertyName = "bname";
            this.书名.HeaderText = "书名";
            this.书名.Name = "书名";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn6.DataPropertyName = "bnum";
            this.dataGridViewTextBoxColumn6.HeaderText = "数量";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // label8预约书号
            // 
            this.label8预约书号.AutoSize = true;
            this.label8预约书号.Font = new System.Drawing.Font("楷体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8预约书号.Location = new System.Drawing.Point(32, 20);
            this.label8预约书号.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8预约书号.Name = "label8预约书号";
            this.label8预约书号.Size = new System.Drawing.Size(85, 24);
            this.label8预约书号.TabIndex = 4;
            this.label8预约书号.Text = "书号：";
            // 
            // button4预约按钮
            // 
            this.button4预约按钮.Location = new System.Drawing.Point(400, 325);
            this.button4预约按钮.Margin = new System.Windows.Forms.Padding(4);
            this.button4预约按钮.Name = "button4预约按钮";
            this.button4预约按钮.Size = new System.Drawing.Size(152, 45);
            this.button4预约按钮.TabIndex = 5;
            this.button4预约按钮.Text = "预约";
            this.button4预约按钮.UseVisualStyleBackColor = true;
            this.button4预约按钮.Click += new System.EventHandler(this.button4预约按钮_Click);
            // 
            // textBox3预约辅助
            // 
            this.textBox3预约辅助.Location = new System.Drawing.Point(669, 171);
            this.textBox3预约辅助.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3预约辅助.Name = "textBox3预约辅助";
            this.textBox3预约辅助.Size = new System.Drawing.Size(132, 25);
            this.textBox3预约辅助.TabIndex = 8;
            // 
            // textBox2预约辅助
            // 
            this.textBox2预约辅助.Location = new System.Drawing.Point(648, 51);
            this.textBox2预约辅助.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2预约辅助.Name = "textBox2预约辅助";
            this.textBox2预约辅助.Size = new System.Drawing.Size(132, 25);
            this.textBox2预约辅助.TabIndex = 6;
            this.textBox2预约辅助.Visible = false;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.label8);
            this.tabPage5.Controls.Add(this.label1预约用户);
            this.tabPage5.Controls.Add(this.dataGridView2预约表);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage5.Size = new System.Drawing.Size(895, 378);
            this.tabPage5.TabIndex = 1;
            this.tabPage5.Text = "查看预约";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 5);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 15);
            this.label8.TabIndex = 12;
            this.label8.Text = "用户：";
            this.label8.Visible = false;
            // 
            // label1预约用户
            // 
            this.label1预约用户.AutoSize = true;
            this.label1预约用户.Location = new System.Drawing.Point(72, 5);
            this.label1预约用户.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1预约用户.Name = "label1预约用户";
            this.label1预约用户.Size = new System.Drawing.Size(115, 15);
            this.label1预约用户.TabIndex = 11;
            this.label1预约用户.Text = "label1预约用户";
            this.label1预约用户.Visible = false;
            // 
            // dataGridView2预约表
            // 
            this.dataGridView2预约表.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2预约表.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.Column4,
            this.Column5});
            this.dataGridView2预约表.Location = new System.Drawing.Point(0, -2);
            this.dataGridView2预约表.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView2预约表.Name = "dataGridView2预约表";
            this.dataGridView2预约表.RowTemplate.Height = 23;
            this.dataGridView2预约表.Size = new System.Drawing.Size(895, 380);
            this.dataGridView2预约表.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn4.DataPropertyName = "username";
            this.dataGridViewTextBoxColumn4.HeaderText = "用户";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "id";
            this.Column4.HeaderText = "书号";
            this.Column4.Name = "Column4";
            this.Column4.Width = 80;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "time";
            this.Column5.HeaderText = "时间";
            this.Column5.Name = "Column5";
            this.Column5.Width = 140;
            // 
            // yijianfankui
            // 
            this.yijianfankui.Controls.Add(this.textBox1留言);
            this.yijianfankui.Controls.Add(this.label10);
            this.yijianfankui.Controls.Add(this.返回留言);
            this.yijianfankui.Controls.Add(this.button2精选留言);
            this.yijianfankui.Controls.Add(this.dataGridView2精选留言);
            this.yijianfankui.Controls.Add(this.button6联系我们);
            this.yijianfankui.Controls.Add(this.button2liuyan);
            this.yijianfankui.Controls.Add(this.label12);
            this.yijianfankui.Controls.Add(this.textBox2特征码);
            this.yijianfankui.Controls.Add(this.label3特征码);
            this.yijianfankui.Controls.Add(this.label1留言);
            this.yijianfankui.Location = new System.Drawing.Point(4, 90);
            this.yijianfankui.Name = "yijianfankui";
            this.yijianfankui.Size = new System.Drawing.Size(903, 409);
            this.yijianfankui.TabIndex = 24;
            this.yijianfankui.TabStop = false;
            // 
            // textBox1留言
            // 
            this.textBox1留言.AcceptsReturn = true;
            this.textBox1留言.AllowDrop = true;
            this.textBox1留言.Location = new System.Drawing.Point(92, 24);
            this.textBox1留言.Multiline = true;
            this.textBox1留言.Name = "textBox1留言";
            this.textBox1留言.Size = new System.Drawing.Size(756, 218);
            this.textBox1留言.TabIndex = 26;
            this.textBox1留言.Text = "请在此处留下您的宝贵意见。";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(327, 171);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 15);
            this.label10.TabIndex = 36;
            this.label10.Text = "用户名";
            this.label10.Visible = false;
            // 
            // 返回留言
            // 
            this.返回留言.Location = new System.Drawing.Point(525, 328);
            this.返回留言.Name = "返回留言";
            this.返回留言.Size = new System.Drawing.Size(148, 43);
            this.返回留言.TabIndex = 34;
            this.返回留言.Text = "返回留言";
            this.返回留言.UseVisualStyleBackColor = true;
            this.返回留言.Visible = false;
            this.返回留言.Click += new System.EventHandler(this.返回留言_Click);
            // 
            // button2精选留言
            // 
            this.button2精选留言.Location = new System.Drawing.Point(206, 328);
            this.button2精选留言.Name = "button2精选留言";
            this.button2精选留言.Size = new System.Drawing.Size(148, 43);
            this.button2精选留言.TabIndex = 35;
            this.button2精选留言.Text = "精选留言";
            this.button2精选留言.UseVisualStyleBackColor = true;
            this.button2精选留言.Click += new System.EventHandler(this.button2精选留言_Click);
            // 
            // dataGridView2精选留言
            // 
            this.dataGridView2精选留言.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2精选留言.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView2精选留言.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2精选留言.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn9});
            this.dataGridView2精选留言.Location = new System.Drawing.Point(92, 24);
            this.dataGridView2精选留言.Name = "dataGridView2精选留言";
            this.dataGridView2精选留言.RowTemplate.Height = 27;
            this.dataGridView2精选留言.Size = new System.Drawing.Size(756, 281);
            this.dataGridView2精选留言.TabIndex = 33;
            this.dataGridView2精选留言.Visible = false;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "username";
            this.dataGridViewTextBoxColumn10.HeaderText = "用户名";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "text";
            this.dataGridViewTextBoxColumn11.HeaderText = "留言内容";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "time";
            this.dataGridViewTextBoxColumn8.HeaderText = "时间";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn7.HeaderText = "特征码";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "jx";
            this.dataGridViewTextBoxColumn9.HeaderText = "精选留言";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // button6联系我们
            // 
            this.button6联系我们.Font = new System.Drawing.Font("宋体", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button6联系我们.Location = new System.Drawing.Point(807, 380);
            this.button6联系我们.Name = "button6联系我们";
            this.button6联系我们.Size = new System.Drawing.Size(96, 29);
            this.button6联系我们.TabIndex = 29;
            this.button6联系我们.Text = "联系我们";
            this.button6联系我们.UseVisualStyleBackColor = true;
            this.button6联系我们.Click += new System.EventHandler(this.button6联系我们_Click);
            // 
            // button2liuyan
            // 
            this.button2liuyan.Location = new System.Drawing.Point(525, 328);
            this.button2liuyan.Name = "button2liuyan";
            this.button2liuyan.Size = new System.Drawing.Size(148, 43);
            this.button2liuyan.TabIndex = 25;
            this.button2liuyan.Text = "留言";
            this.button2liuyan.UseVisualStyleBackColor = true;
            this.button2liuyan.Click += new System.EventHandler(this.button2_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(331, 269);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 15);
            this.label12.TabIndex = 32;
            this.label12.Text = "特征码：";
            // 
            // textBox2特征码
            // 
            this.textBox2特征码.Location = new System.Drawing.Point(404, 266);
            this.textBox2特征码.Name = "textBox2特征码";
            this.textBox2特征码.Size = new System.Drawing.Size(100, 25);
            this.textBox2特征码.TabIndex = 31;
            // 
            // label3特征码
            // 
            this.label3特征码.AutoSize = true;
            this.label3特征码.Location = new System.Drawing.Point(529, 269);
            this.label3特征码.Name = "label3特征码";
            this.label3特征码.Size = new System.Drawing.Size(55, 15);
            this.label3特征码.TabIndex = 30;
            this.label3特征码.Text = "label3";
            // 
            // label1留言
            // 
            this.label1留言.AutoSize = true;
            this.label1留言.Location = new System.Drawing.Point(405, 171);
            this.label1留言.Name = "label1留言";
            this.label1留言.Size = new System.Drawing.Size(55, 15);
            this.label1留言.TabIndex = 27;
            this.label1留言.Text = "label1";
            this.label1留言.Visible = false;
            // 
            // xiaoxitixing
            // 
            this.xiaoxitixing.Controls.Add(this.tabControl2);
            this.xiaoxitixing.Location = new System.Drawing.Point(4, 90);
            this.xiaoxitixing.Name = "xiaoxitixing";
            this.xiaoxitixing.Size = new System.Drawing.Size(903, 409);
            this.xiaoxitixing.TabIndex = 0;
            this.xiaoxitixing.TabStop = false;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Controls.Add(this.tabPage9);
            this.tabControl2.Location = new System.Drawing.Point(0, 9);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(903, 400);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.dataGridView1siliao);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(895, 371);
            this.tabPage7.TabIndex = 0;
            this.tabPage7.Text = "私聊消息";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // dataGridView1siliao
            // 
            this.dataGridView1siliao.AllowUserToDeleteRows = false;
            this.dataGridView1siliao.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1siliao.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column10,
            this.Column6,
            this.Column16,
            this.Column11,
            this.Column17});
            this.dataGridView1siliao.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1siliao.Name = "dataGridView1siliao";
            this.dataGridView1siliao.RowTemplate.Height = 27;
            this.dataGridView1siliao.Size = new System.Drawing.Size(895, 371);
            this.dataGridView1siliao.TabIndex = 0;
            // 
            // Column10
            // 
            this.Column10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column10.DataPropertyName = "username";
            this.Column10.HeaderText = "用户名";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column6.DataPropertyName = "text";
            this.Column6.HeaderText = "内容";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column16
            // 
            this.Column16.DataPropertyName = "sender";
            this.Column16.HeaderText = "发送者";
            this.Column16.Name = "Column16";
            // 
            // Column11
            // 
            this.Column11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column11.DataPropertyName = "time";
            this.Column11.HeaderText = "时间";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            // 
            // Column17
            // 
            this.Column17.DataPropertyName = "isread";
            this.Column17.HeaderText = "是否已读";
            this.Column17.Name = "Column17";
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.dataGridView1qb);
            this.tabPage8.Location = new System.Drawing.Point(4, 25);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(895, 371);
            this.tabPage8.TabIndex = 1;
            this.tabPage8.Text = "全部广播";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // dataGridView1qb
            // 
            this.dataGridView1qb.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1qb.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15});
            this.dataGridView1qb.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1qb.Name = "dataGridView1qb";
            this.dataGridView1qb.RowTemplate.Height = 27;
            this.dataGridView1qb.Size = new System.Drawing.Size(895, 371);
            this.dataGridView1qb.TabIndex = 0;
            // 
            // Column12
            // 
            this.Column12.DataPropertyName = "id";
            this.Column12.HeaderText = "编号";
            this.Column12.Name = "Column12";
            // 
            // Column13
            // 
            this.Column13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column13.DataPropertyName = "text";
            this.Column13.HeaderText = "内容";
            this.Column13.Name = "Column13";
            // 
            // Column14
            // 
            this.Column14.DataPropertyName = "time";
            this.Column14.HeaderText = "时间";
            this.Column14.Name = "Column14";
            // 
            // Column15
            // 
            this.Column15.DataPropertyName = "sender";
            this.Column15.HeaderText = "发送者";
            this.Column15.Name = "Column15";
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.button1fasong);
            this.tabPage9.Controls.Add(this.textBox2id);
            this.tabPage9.Controls.Add(this.label11);
            this.tabPage9.Controls.Add(this.nr);
            this.tabPage9.Controls.Add(this.textBox1message);
            this.tabPage9.Location = new System.Drawing.Point(4, 25);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(895, 371);
            this.tabPage9.TabIndex = 2;
            this.tabPage9.Text = "发送消息";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // button1fasong
            // 
            this.button1fasong.Location = new System.Drawing.Point(402, 262);
            this.button1fasong.Name = "button1fasong";
            this.button1fasong.Size = new System.Drawing.Size(164, 40);
            this.button1fasong.TabIndex = 4;
            this.button1fasong.Text = "发送";
            this.button1fasong.UseVisualStyleBackColor = true;
            this.button1fasong.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2id
            // 
            this.textBox2id.Location = new System.Drawing.Point(201, 208);
            this.textBox2id.Name = "textBox2id";
            this.textBox2id.Size = new System.Drawing.Size(563, 25);
            this.textBox2id.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(53, 211);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 15);
            this.label11.TabIndex = 2;
            this.label11.Text = "发送至：";
            // 
            // nr
            // 
            this.nr.AutoSize = true;
            this.nr.Location = new System.Drawing.Point(53, 53);
            this.nr.Name = "nr";
            this.nr.Size = new System.Drawing.Size(52, 15);
            this.nr.TabIndex = 1;
            this.nr.Text = "内容：";
            // 
            // textBox1message
            // 
            this.textBox1message.AcceptsReturn = true;
            this.textBox1message.AcceptsTab = true;
            this.textBox1message.Location = new System.Drawing.Point(202, 33);
            this.textBox1message.Multiline = true;
            this.textBox1message.Name = "textBox1message";
            this.textBox1message.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.textBox1message.Size = new System.Drawing.Size(562, 150);
            this.textBox1message.TabIndex = 0;
            // 
            // jiehuanyewu
            // 
            this.jiehuanyewu.Controls.Add(this.tabControl1);
            this.jiehuanyewu.Location = new System.Drawing.Point(4, 90);
            this.jiehuanyewu.Name = "jiehuanyewu";
            this.jiehuanyewu.Size = new System.Drawing.Size(903, 409);
            this.jiehuanyewu.TabIndex = 25;
            this.jiehuanyewu.TabStop = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(0, 9);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(903, 400);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Linen;
            this.tabPage1.Controls.Add(this.zs3);
            this.tabPage1.Controls.Add(this.dataGridView1借书表);
            this.tabPage1.Controls.Add(this.button5查询);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.textBox7书名);
            this.tabPage1.Controls.Add(this.textBox8书号);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.textBox3辅助);
            this.tabPage1.Controls.Add(this.textBox2辅助1);
            this.tabPage1.Controls.Add(this.label1用户);
            this.tabPage1.Controls.Add(this.button1借书按钮);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(895, 371);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "借书";
            // 
            // zs3
            // 
            this.zs3.Location = new System.Drawing.Point(402, -5);
            this.zs3.Name = "zs3";
            this.zs3.Size = new System.Drawing.Size(10, 388);
            this.zs3.TabIndex = 14;
            this.zs3.Text = "button1";
            this.zs3.UseVisualStyleBackColor = true;
            // 
            // dataGridView1借书表
            // 
            this.dataGridView1借书表.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1借书表.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1借书表.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            this.dataGridView1借书表.Location = new System.Drawing.Point(436, 6);
            this.dataGridView1借书表.Name = "dataGridView1借书表";
            this.dataGridView1借书表.RowTemplate.Height = 27;
            this.dataGridView1借书表.Size = new System.Drawing.Size(453, 312);
            this.dataGridView1借书表.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "id";
            this.Column1.HeaderText = "书号";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "bname";
            this.Column2.HeaderText = "书名";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "bnum";
            this.Column3.HeaderText = "数量";
            this.Column3.Name = "Column3";
            // 
            // button5查询
            // 
            this.button5查询.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button5查询.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button5查询.Location = new System.Drawing.Point(103, 296);
            this.button5查询.Name = "button5查询";
            this.button5查询.Size = new System.Drawing.Size(163, 33);
            this.button5查询.TabIndex = 13;
            this.button5查询.Text = "查询";
            this.button5查询.UseVisualStyleBackColor = true;
            this.button5查询.Click += new System.EventHandler(this.button5查询_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label16.Location = new System.Drawing.Point(38, 187);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 24);
            this.label16.TabIndex = 12;
            this.label16.Text = "书名";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label15.Location = new System.Drawing.Point(38, 98);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(60, 24);
            this.label15.TabIndex = 11;
            this.label15.Text = "书号";
            // 
            // textBox7书名
            // 
            this.textBox7书名.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox7书名.Location = new System.Drawing.Point(179, 177);
            this.textBox7书名.Name = "textBox7书名";
            this.textBox7书名.Size = new System.Drawing.Size(164, 34);
            this.textBox7书名.TabIndex = 10;
            // 
            // textBox8书号
            // 
            this.textBox8书号.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox8书号.Location = new System.Drawing.Point(179, 88);
            this.textBox8书号.Name = "textBox8书号";
            this.textBox8书号.Size = new System.Drawing.Size(164, 34);
            this.textBox8书号.TabIndex = 9;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label14.Location = new System.Drawing.Point(7, 19);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(110, 24);
            this.label14.TabIndex = 8;
            this.label14.Text = "查询条件";
            // 
            // textBox3辅助
            // 
            this.textBox3辅助.Location = new System.Drawing.Point(481, 123);
            this.textBox3辅助.Name = "textBox3辅助";
            this.textBox3辅助.Size = new System.Drawing.Size(100, 25);
            this.textBox3辅助.TabIndex = 4;
            this.textBox3辅助.Visible = false;
            // 
            // textBox2辅助1
            // 
            this.textBox2辅助1.Location = new System.Drawing.Point(472, 123);
            this.textBox2辅助1.Name = "textBox2辅助1";
            this.textBox2辅助1.Size = new System.Drawing.Size(100, 25);
            this.textBox2辅助1.TabIndex = 3;
            this.textBox2辅助1.Visible = false;
            // 
            // label1用户
            // 
            this.label1用户.AutoSize = true;
            this.label1用户.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1用户.Location = new System.Drawing.Point(517, 126);
            this.label1用户.Name = "label1用户";
            this.label1用户.Size = new System.Drawing.Size(55, 15);
            this.label1用户.TabIndex = 2;
            this.label1用户.Text = "label1";
            this.label1用户.Visible = false;
            // 
            // button1借书按钮
            // 
            this.button1借书按钮.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button1借书按钮.Location = new System.Drawing.Point(599, 324);
            this.button1借书按钮.Name = "button1借书按钮";
            this.button1借书按钮.Size = new System.Drawing.Size(166, 44);
            this.button1借书按钮.TabIndex = 1;
            this.button1借书按钮.Text = "借阅书籍";
            this.button1借书按钮.UseVisualStyleBackColor = true;
            this.button1借书按钮.Click += new System.EventHandler(this.button1借书按钮_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Linen;
            this.tabPage2.Controls.Add(this.textBox1书号);
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Controls.Add(this.label22用户);
            this.tabPage2.Controls.Add(this.button2还书按钮);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(895, 371);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "还书";
            // 
            // textBox1书号
            // 
            this.textBox1书号.Location = new System.Drawing.Point(402, 142);
            this.textBox1书号.Name = "textBox1书号";
            this.textBox1书号.Size = new System.Drawing.Size(165, 25);
            this.textBox1书号.TabIndex = 6;
            this.textBox1书号.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label17.Location = new System.Drawing.Point(338, 153);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(68, 15);
            this.label17.TabIndex = 5;
            this.label17.Text = "书  号：";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label18.Location = new System.Drawing.Point(338, 73);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(67, 15);
            this.label18.TabIndex = 4;
            this.label18.Text = "用户名：";
            // 
            // label22用户
            // 
            this.label22用户.AutoSize = true;
            this.label22用户.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label22用户.Location = new System.Drawing.Point(456, 73);
            this.label22用户.Name = "label22用户";
            this.label22用户.Size = new System.Drawing.Size(55, 15);
            this.label22用户.TabIndex = 3;
            this.label22用户.Text = "label2";
            // 
            // button2还书按钮
            // 
            this.button2还书按钮.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button2还书按钮.Location = new System.Drawing.Point(371, 247);
            this.button2还书按钮.Name = "button2还书按钮";
            this.button2还书按钮.Size = new System.Drawing.Size(172, 50);
            this.button2还书按钮.TabIndex = 1;
            this.button2还书按钮.Text = "还书";
            this.button2还书按钮.UseVisualStyleBackColor = true;
            this.button2还书按钮.Click += new System.EventHandler(this.button2还书按钮_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dataGridView3借阅信息);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(895, 371);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "借阅信息";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dataGridView3借阅信息
            // 
            this.dataGridView3借阅信息.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView3借阅信息.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3借阅信息.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column7,
            this.Column8,
            this.Column9});
            this.dataGridView3借阅信息.Location = new System.Drawing.Point(0, 0);
            this.dataGridView3借阅信息.Name = "dataGridView3借阅信息";
            this.dataGridView3借阅信息.RowTemplate.Height = 27;
            this.dataGridView3借阅信息.Size = new System.Drawing.Size(893, 371);
            this.dataGridView3借阅信息.TabIndex = 0;
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column7.DataPropertyName = "username";
            this.Column7.HeaderText = "用户名";
            this.Column7.Name = "Column7";
            // 
            // Column8
            // 
            this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column8.DataPropertyName = "id";
            this.Column8.HeaderText = "书号";
            this.Column8.Name = "Column8";
            // 
            // Column9
            // 
            this.Column9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column9.DataPropertyName = "time";
            this.Column9.HeaderText = "时间";
            this.Column9.Name = "Column9";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dataGridView2还书信息);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(895, 371);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "还书信息";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dataGridView2还书信息
            // 
            this.dataGridView2还书信息.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2还书信息.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2还书信息.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.dataGridView2还书信息.Location = new System.Drawing.Point(0, 0);
            this.dataGridView2还书信息.Name = "dataGridView2还书信息";
            this.dataGridView2还书信息.RowTemplate.Height = 27;
            this.dataGridView2还书信息.Size = new System.Drawing.Size(895, 375);
            this.dataGridView2还书信息.TabIndex = 22;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "username";
            this.dataGridViewTextBoxColumn1.HeaderText = "用户名";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn2.HeaderText = "书号";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.DataPropertyName = "time";
            this.dataGridViewTextBoxColumn3.HeaderText = "时间";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // timerxiaoxi
            // 
            this.timerxiaoxi.Enabled = true;
            this.timerxiaoxi.Interval = 1000;
            this.timerxiaoxi.Tick += new System.EventHandler(this.timerxiaoxi_Tick);
            // 
            // flaglabel1
            // 
            this.flaglabel1.AutoSize = true;
            this.flaglabel1.BackColor = System.Drawing.Color.Red;
            this.flaglabel1.Font = new System.Drawing.Font("幼圆", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.flaglabel1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.flaglabel1.Location = new System.Drawing.Point(881, 55);
            this.flaglabel1.Name = "flaglabel1";
            this.flaglabel1.Size = new System.Drawing.Size(20, 19);
            this.flaglabel1.TabIndex = 26;
            this.flaglabel1.Text = "!";
            this.flaglabel1.Visible = false;
            // 
            // rereadtimer1
            // 
            this.rereadtimer1.Enabled = true;
            this.rereadtimer1.Interval = 10000;
            this.rereadtimer1.Tick += new System.EventHandler(this.rereadtimer1_Tick);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 15;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Interval = 200;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // MainForm_user
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(910, 502);
            this.Controls.Add(this.xiaoxitixing);
            this.Controls.Add(this.jiehuanyewu);
            this.Controls.Add(this.flaglabel1);
            this.Controls.Add(this.yuyueyewu);
            this.Controls.Add(this.yijianfankui);
            this.Controls.Add(this.xinxigenggai);
            this.Controls.Add(this.消息提醒);
            this.Controls.Add(this.借还业务);
            this.Controls.Add(this.预约业务);
            this.Controls.Add(this.信息修改);
            this.Controls.Add(this.意见反馈);
            this.Controls.Add(this.图书一览);
            this.Controls.Add(this.zs2);
            this.Controls.Add(this.zs1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tushuyilan);
            this.MaximizeBox = false;
            this.Name = "MainForm_user";
            this.Text = "图书管理系统_user";
            this.Load += new System.EventHandler(this.MainForm_user_Load);
            this.tushuyilan.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView查看图书)).EndInit();
            this.xinxigenggai.ResumeLayout(false);
            this.xinxigenggai.PerformLayout();
            this.yuyueyewu.ResumeLayout(false);
            this.图书预约.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1预约显示)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2预约表)).EndInit();
            this.yijianfankui.ResumeLayout(false);
            this.yijianfankui.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2精选留言)).EndInit();
            this.xiaoxitixing.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1siliao)).EndInit();
            this.tabPage8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1qb)).EndInit();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            this.jiehuanyewu.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1借书表)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3借阅信息)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2还书信息)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button 消息提醒;
        private System.Windows.Forms.Button 借还业务;
        private System.Windows.Forms.Button 预约业务;
        private System.Windows.Forms.Button 信息修改;
        private System.Windows.Forms.Button 意见反馈;
        private System.Windows.Forms.Button 图书一览;
        private System.Windows.Forms.Button zs2;
        private System.Windows.Forms.Button zs1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox tushuyilan;
        private System.Windows.Forms.DataGridView dataGridView查看图书;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn bname;
        private System.Windows.Forms.DataGridViewTextBoxColumn bnum;
        private System.Windows.Forms.GroupBox xinxigenggai;
        private System.Windows.Forms.Label label6yonghu;
        private System.Windows.Forms.Button button4qq修改;
        private System.Windows.Forms.Button button3年龄修改;
        private System.Windows.Forms.Button button2性别修改;
        private System.Windows.Forms.Button button1密码修改;
        private System.Windows.Forms.TextBox textBox5qq;
        private System.Windows.Forms.TextBox textBox4nianling;
        private System.Windows.Forms.TextBox textBox3xingbie;
        private System.Windows.Forms.TextBox textBoxmima;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox yuyueyewu;
        private System.Windows.Forms.GroupBox yijianfankui;
        private System.Windows.Forms.GroupBox xiaoxitixing;
        private System.Windows.Forms.GroupBox jiehuanyewu;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button zs3;
        private System.Windows.Forms.DataGridView dataGridView1借书表;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.Button button5查询;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox7书名;
        private System.Windows.Forms.TextBox textBox8书号;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox3辅助;
        private System.Windows.Forms.TextBox textBox2辅助1;
        private System.Windows.Forms.Label label1用户;
        private System.Windows.Forms.Button button1借书按钮;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBox1书号;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label22用户;
        private System.Windows.Forms.Button button2还书按钮;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridView3借阅信息;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dataGridView2还书信息;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.TabControl 图书预约;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button button1预约查询;
        private System.Windows.Forms.TextBox textBox4预约书名;
        private System.Windows.Forms.TextBox textBox1预约书号;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView dataGridView1预约显示;
        private System.Windows.Forms.Label label8预约书号;
        private System.Windows.Forms.Button button4预约按钮;
        private System.Windows.Forms.TextBox textBox3预约辅助;
        private System.Windows.Forms.TextBox textBox2预约辅助;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1预约用户;
        private System.Windows.Forms.DataGridView dataGridView2预约表;
        private System.Windows.Forms.TextBox textBox1留言;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button 返回留言;
        private System.Windows.Forms.Button button2精选留言;
        private System.Windows.Forms.DataGridView dataGridView2精选留言;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.Button button6联系我们;
        private System.Windows.Forms.Button button2liuyan;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox2特征码;
        private System.Windows.Forms.Label label3特征码;
        private System.Windows.Forms.Label label1留言;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.DataGridView dataGridView1siliao;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.Timer timerxiaoxi;
        private System.Windows.Forms.DataGridView dataGridView1qb;
        private System.Windows.Forms.Button button1fasong;
        private System.Windows.Forms.TextBox textBox2id;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label nr;
        private System.Windows.Forms.TextBox textBox1message;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.Label flaglabel1;
        private System.Windows.Forms.Timer rereadtimer1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn 书名;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
    }
}