﻿namespace 图书馆系统
{
    partial class MainForm_admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tushuguanli = new System.Windows.Forms.GroupBox();
            this.图书夹 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.textBox3shuliang = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox1shuhao = new System.Windows.Forms.TextBox();
            this.textBox2shuming = new System.Windows.Forms.TextBox();
            this.button1tianjiatushu = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button3shuliangxiugai = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox4shuliang = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox5shuhao = new System.Windows.Forms.TextBox();
            this.textBox6shuming = new System.Windows.Forms.TextBox();
            this.button2shumingxiugai = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button4shanchuanniu = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.dataGridView1shanchutushuxianshi = new System.Windows.Forms.DataGridView();
            this.书名 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jieyueguanli = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xiaoxiguanli = new System.Windows.Forms.GroupBox();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.button8 = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.button10 = new System.Windows.Forms.Button();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.textBox2id = new System.Windows.Forms.TextBox();
            this.textBox1message = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.tushuyilan = new System.Windows.Forms.GroupBox();
            this.dataGridView111222 = new System.Windows.Forms.DataGridView();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2radiocheck = new System.Windows.Forms.Timer(this.components);
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button3qvxiaojingxuan = new System.Windows.Forms.Button();
            this.dataGridView2jingxuanliuyan = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.duzheguanli = new System.Windows.Forms.GroupBox();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.button12 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox11duzheming = new System.Windows.Forms.TextBox();
            this.textBox10duzhenianling = new System.Windows.Forms.TextBox();
            this.button5chaxun = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.读者信息修改 = new System.Windows.Forms.Label();
            this.button4duzheqq = new System.Windows.Forms.Button();
            this.button3duzhemnian = new System.Windows.Forms.Button();
            this.button2duzhexing = new System.Windows.Forms.Button();
            this.button1duzhemi = new System.Windows.Forms.Button();
            this.textBox5duzheqq = new System.Windows.Forms.TextBox();
            this.textBox4duzhenian = new System.Windows.Forms.TextBox();
            this.textBox3duzhexing = new System.Windows.Forms.TextBox();
            this.textBox2duzhemi = new System.Windows.Forms.TextBox();
            this.textBox1duzheming = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.button6shensutongyi = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.dataGridView2zhanghaoshensu = new System.Windows.Forms.DataGridView();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.liuyanguanli = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button2jingxuanliuyan = new System.Windows.Forms.Button();
            this.button1shanchuliuyan = new System.Windows.Forms.Button();
            this.dataGridView1chakanliuyan = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tushuguanli.SuspendLayout();
            this.图书夹.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1shanchutushuxianshi)).BeginInit();
            this.jieyueguanli.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.xiaoxiguanli.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.tabPage11.SuspendLayout();
            this.tushuyilan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView111222)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2jingxuanliuyan)).BeginInit();
            this.duzheguanli.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage8.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2zhanghaoshensu)).BeginInit();
            this.liuyanguanli.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1chakanliuyan)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 42);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(194, 66);
            this.button1.TabIndex = 0;
            this.button1.Text = "图书一览";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(0, 293);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(194, 66);
            this.button2.TabIndex = 1;
            this.button2.Text = "读者管理";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(0, 168);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(194, 66);
            this.button3.TabIndex = 2;
            this.button3.Text = "消息管理";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(0, 231);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(194, 66);
            this.button4.TabIndex = 3;
            this.button4.Text = "留言管理";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(0, 105);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(194, 66);
            this.button5.TabIndex = 4;
            this.button5.Text = "借阅管理";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Info;
            this.label1.Font = new System.Drawing.Font("楷体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(876, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1219, 20);
            this.label1.TabIndex = 13;
            this.label1.Text = "欢迎您使用图书管理系统管理端！ 如需帮助可通过联系我们与我们取得联系，若您对本产品有意见或建议，请通过意见反馈向我们提出！";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Info;
            this.label2.Font = new System.Drawing.Font("宋体", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.SystemColors.Info;
            this.label2.Location = new System.Drawing.Point(-8, -4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(2505, 43);
            this.label2.TabIndex = 14;
            this.label2.Text = "                                                                                 " +
    "                                ";
            // 
            // tushuguanli
            // 
            this.tushuguanli.Controls.Add(this.图书夹);
            this.tushuguanli.Location = new System.Drawing.Point(200, 42);
            this.tushuguanli.Name = "tushuguanli";
            this.tushuguanli.Size = new System.Drawing.Size(721, 380);
            this.tushuguanli.TabIndex = 15;
            this.tushuguanli.TabStop = false;
            // 
            // 图书夹
            // 
            this.图书夹.Controls.Add(this.tabPage1);
            this.图书夹.Controls.Add(this.tabPage2);
            this.图书夹.Controls.Add(this.tabPage3);
            this.图书夹.Location = new System.Drawing.Point(1, 5);
            this.图书夹.Margin = new System.Windows.Forms.Padding(4);
            this.图书夹.Name = "图书夹";
            this.图书夹.SelectedIndex = 0;
            this.图书夹.Size = new System.Drawing.Size(713, 375);
            this.图书夹.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.textBox3shuliang);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.textBox1shuhao);
            this.tabPage1.Controls.Add(this.textBox2shuming);
            this.tabPage1.Controls.Add(this.button1tianjiatushu);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(705, 346);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "图书入库";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // textBox3shuliang
            // 
            this.textBox3shuliang.Location = new System.Drawing.Point(269, 199);
            this.textBox3shuliang.Margin = new System.Windows.Forms.Padding(4);
            this.textBox3shuliang.Name = "textBox3shuliang";
            this.textBox3shuliang.Size = new System.Drawing.Size(173, 25);
            this.textBox3shuliang.TabIndex = 6;
            this.textBox3shuliang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(205, 199);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "数量:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(205, 125);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 15);
            this.label4.TabIndex = 4;
            this.label4.Text = "书名：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(205, 56);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 15);
            this.label5.TabIndex = 3;
            this.label5.Text = "书号：";
            // 
            // textBox1shuhao
            // 
            this.textBox1shuhao.Location = new System.Drawing.Point(268, 56);
            this.textBox1shuhao.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1shuhao.Name = "textBox1shuhao";
            this.textBox1shuhao.Size = new System.Drawing.Size(175, 25);
            this.textBox1shuhao.TabIndex = 1;
            this.textBox1shuhao.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2shuming
            // 
            this.textBox2shuming.Location = new System.Drawing.Point(268, 125);
            this.textBox2shuming.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2shuming.Name = "textBox2shuming";
            this.textBox2shuming.Size = new System.Drawing.Size(175, 25);
            this.textBox2shuming.TabIndex = 2;
            this.textBox2shuming.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button1tianjiatushu
            // 
            this.button1tianjiatushu.Location = new System.Drawing.Point(294, 294);
            this.button1tianjiatushu.Margin = new System.Windows.Forms.Padding(4);
            this.button1tianjiatushu.Name = "button1tianjiatushu";
            this.button1tianjiatushu.Size = new System.Drawing.Size(100, 29);
            this.button1tianjiatushu.TabIndex = 0;
            this.button1tianjiatushu.Text = "添加图书";
            this.button1tianjiatushu.UseVisualStyleBackColor = true;
            this.button1tianjiatushu.Click += new System.EventHandler(this.button1tianjiatushu_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button3shuliangxiugai);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.textBox4shuliang);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.textBox5shuhao);
            this.tabPage2.Controls.Add(this.textBox6shuming);
            this.tabPage2.Controls.Add(this.button2shumingxiugai);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(705, 346);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "图书修改";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button3shuliangxiugai
            // 
            this.button3shuliangxiugai.Location = new System.Drawing.Point(386, 268);
            this.button3shuliangxiugai.Margin = new System.Windows.Forms.Padding(4);
            this.button3shuliangxiugai.Name = "button3shuliangxiugai";
            this.button3shuliangxiugai.Size = new System.Drawing.Size(100, 29);
            this.button3shuliangxiugai.TabIndex = 15;
            this.button3shuliangxiugai.Text = "修改数量";
            this.button3shuliangxiugai.UseVisualStyleBackColor = true;
            this.button3shuliangxiugai.Click += new System.EventHandler(this.button3shuliangxiugai_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(4, 24);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(202, 15);
            this.label7.TabIndex = 14;
            this.label7.Text = "请输入书号，选择修改项目：";
            // 
            // textBox4shuliang
            // 
            this.textBox4shuliang.Location = new System.Drawing.Point(289, 191);
            this.textBox4shuliang.Margin = new System.Windows.Forms.Padding(4);
            this.textBox4shuliang.Name = "textBox4shuliang";
            this.textBox4shuliang.Size = new System.Drawing.Size(173, 25);
            this.textBox4shuliang.TabIndex = 13;
            this.textBox4shuliang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(226, 191);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 15);
            this.label6.TabIndex = 12;
            this.label6.Text = "数量:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(226, 136);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 15);
            this.label9.TabIndex = 11;
            this.label9.Text = "书名：";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(226, 84);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 15);
            this.label10.TabIndex = 10;
            this.label10.Text = "书号：";
            // 
            // textBox5shuhao
            // 
            this.textBox5shuhao.Location = new System.Drawing.Point(287, 84);
            this.textBox5shuhao.Margin = new System.Windows.Forms.Padding(4);
            this.textBox5shuhao.Name = "textBox5shuhao";
            this.textBox5shuhao.Size = new System.Drawing.Size(175, 25);
            this.textBox5shuhao.TabIndex = 8;
            this.textBox5shuhao.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox6shuming
            // 
            this.textBox6shuming.Location = new System.Drawing.Point(289, 136);
            this.textBox6shuming.Margin = new System.Windows.Forms.Padding(4);
            this.textBox6shuming.Name = "textBox6shuming";
            this.textBox6shuming.Size = new System.Drawing.Size(175, 25);
            this.textBox6shuming.TabIndex = 9;
            this.textBox6shuming.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button2shumingxiugai
            // 
            this.button2shumingxiugai.Location = new System.Drawing.Point(229, 268);
            this.button2shumingxiugai.Margin = new System.Windows.Forms.Padding(4);
            this.button2shumingxiugai.Name = "button2shumingxiugai";
            this.button2shumingxiugai.Size = new System.Drawing.Size(100, 29);
            this.button2shumingxiugai.TabIndex = 7;
            this.button2shumingxiugai.Text = "修改书名";
            this.button2shumingxiugai.UseVisualStyleBackColor = true;
            this.button2shumingxiugai.Click += new System.EventHandler(this.button2shumingxiugai_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button4shanchuanniu);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.dataGridView1shanchutushuxianshi);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage3.Size = new System.Drawing.Size(705, 346);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "删除图书";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button4shanchuanniu
            // 
            this.button4shanchuanniu.Location = new System.Drawing.Point(294, 304);
            this.button4shanchuanniu.Margin = new System.Windows.Forms.Padding(4);
            this.button4shanchuanniu.Name = "button4shanchuanniu";
            this.button4shanchuanniu.Size = new System.Drawing.Size(100, 35);
            this.button4shanchuanniu.TabIndex = 2;
            this.button4shanchuanniu.Text = "删除";
            this.button4shanchuanniu.UseVisualStyleBackColor = true;
            this.button4shanchuanniu.Click += new System.EventHandler(this.button4shanchuanniu_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 4);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 15);
            this.label8.TabIndex = 1;
            this.label8.Text = "图书信息如下：";
            // 
            // dataGridView1shanchutushuxianshi
            // 
            this.dataGridView1shanchutushuxianshi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1shanchutushuxianshi.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.书名,
            this.Column1,
            this.Column2});
            this.dataGridView1shanchutushuxianshi.Location = new System.Drawing.Point(8, 22);
            this.dataGridView1shanchutushuxianshi.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1shanchutushuxianshi.Name = "dataGridView1shanchutushuxianshi";
            this.dataGridView1shanchutushuxianshi.RowTemplate.Height = 23;
            this.dataGridView1shanchutushuxianshi.Size = new System.Drawing.Size(689, 274);
            this.dataGridView1shanchutushuxianshi.TabIndex = 0;
            // 
            // 书名
            // 
            this.书名.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.书名.DataPropertyName = "id";
            this.书名.HeaderText = "书号";
            this.书名.Name = "书名";
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.DataPropertyName = "bname";
            this.Column1.HeaderText = "书名";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.DataPropertyName = "bnum";
            this.Column2.HeaderText = "数量";
            this.Column2.Name = "Column2";
            // 
            // jieyueguanli
            // 
            this.jieyueguanli.Controls.Add(this.button7);
            this.jieyueguanli.Controls.Add(this.label19);
            this.jieyueguanli.Controls.Add(this.label20);
            this.jieyueguanli.Controls.Add(this.textBox4);
            this.jieyueguanli.Controls.Add(this.textBox5);
            this.jieyueguanli.Controls.Add(this.label21);
            this.jieyueguanli.Controls.Add(this.button9);
            this.jieyueguanli.Controls.Add(this.textBox6);
            this.jieyueguanli.Controls.Add(this.dataGridView3);
            this.jieyueguanli.Location = new System.Drawing.Point(200, 42);
            this.jieyueguanli.Name = "jieyueguanli";
            this.jieyueguanli.Size = new System.Drawing.Size(721, 380);
            this.jieyueguanli.TabIndex = 16;
            this.jieyueguanli.TabStop = false;
            // 
            // button7
            // 
            this.button7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button7.Location = new System.Drawing.Point(606, 49);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(109, 38);
            this.button7.TabIndex = 39;
            this.button7.Text = "借书查询";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label19.Location = new System.Drawing.Point(327, 26);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(272, 15);
            this.label19.TabIndex = 38;
            this.label19.Text = "按时间查询：（2022/5/22 10:22:04 )";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label20.Location = new System.Drawing.Point(171, 26);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(45, 15);
            this.label20.TabIndex = 37;
            this.label20.Text = "书号:";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(330, 49);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(270, 25);
            this.textBox4.TabIndex = 34;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(174, 49);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(150, 25);
            this.textBox5.TabIndex = 33;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label21.Location = new System.Drawing.Point(14, 26);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(60, 15);
            this.label21.TabIndex = 36;
            this.label21.Text = "用户名:";
            // 
            // button9
            // 
            this.button9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button9.Location = new System.Drawing.Point(606, 14);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(109, 38);
            this.button9.TabIndex = 35;
            this.button9.Text = "还书查询";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(13, 49);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(154, 25);
            this.textBox6.TabIndex = 32;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15});
            this.dataGridView3.Location = new System.Drawing.Point(6, 93);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowTemplate.Height = 27;
            this.dataGridView3.Size = new System.Drawing.Size(709, 281);
            this.dataGridView3.TabIndex = 22;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn13.DataPropertyName = "username";
            this.dataGridViewTextBoxColumn13.HeaderText = "用户名";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn14.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn14.HeaderText = "书号";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn15.DataPropertyName = "time";
            this.dataGridViewTextBoxColumn15.HeaderText = "时间";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // xiaoxiguanli
            // 
            this.xiaoxiguanli.Controls.Add(this.tabControl3);
            this.xiaoxiguanli.Location = new System.Drawing.Point(200, 42);
            this.xiaoxiguanli.Name = "xiaoxiguanli";
            this.xiaoxiguanli.Size = new System.Drawing.Size(721, 380);
            this.xiaoxiguanli.TabIndex = 16;
            this.xiaoxiguanli.TabStop = false;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage9);
            this.tabControl3.Controls.Add(this.tabPage10);
            this.tabControl3.Controls.Add(this.tabPage11);
            this.tabControl3.Location = new System.Drawing.Point(6, 14);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(715, 366);
            this.tabControl3.TabIndex = 1;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.dataGridView2);
            this.tabPage9.Location = new System.Drawing.Point(4, 25);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(707, 337);
            this.tabPage9.TabIndex = 0;
            this.tabPage9.Text = "私聊消息查看";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column17,
            this.Column18,
            this.Column19,
            this.Column20,
            this.Column21});
            this.dataGridView2.Location = new System.Drawing.Point(3, 3);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 27;
            this.dataGridView2.Size = new System.Drawing.Size(704, 275);
            this.dataGridView2.TabIndex = 0;
            // 
            // Column17
            // 
            this.Column17.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column17.DataPropertyName = "username";
            this.Column17.HeaderText = "User";
            this.Column17.Name = "Column17";
            this.Column17.ReadOnly = true;
            // 
            // Column18
            // 
            this.Column18.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column18.DataPropertyName = "text";
            this.Column18.HeaderText = "Text";
            this.Column18.Name = "Column18";
            this.Column18.ReadOnly = true;
            // 
            // Column19
            // 
            this.Column19.DataPropertyName = "time";
            this.Column19.HeaderText = "Time";
            this.Column19.Name = "Column19";
            this.Column19.ReadOnly = true;
            // 
            // Column20
            // 
            this.Column20.DataPropertyName = "sender";
            this.Column20.HeaderText = "Sender";
            this.Column20.Name = "Column20";
            this.Column20.ReadOnly = true;
            // 
            // Column21
            // 
            this.Column21.DataPropertyName = "isread";
            this.Column21.HeaderText = "Isread";
            this.Column21.Name = "Column21";
            this.Column21.ReadOnly = true;
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.button8);
            this.tabPage10.Controls.Add(this.dataGridView4);
            this.tabPage10.Location = new System.Drawing.Point(4, 25);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(707, 337);
            this.tabPage10.TabIndex = 1;
            this.tabPage10.Text = "全馆消息管理";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(277, 289);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(119, 45);
            this.button8.TabIndex = 2;
            this.button8.Text = "删除";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click_1);
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column13,
            this.Column15,
            this.Column16,
            this.Column14});
            this.dataGridView4.Location = new System.Drawing.Point(3, 3);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowTemplate.Height = 27;
            this.dataGridView4.Size = new System.Drawing.Size(704, 280);
            this.dataGridView4.TabIndex = 0;
            // 
            // Column13
            // 
            this.Column13.DataPropertyName = "id";
            this.Column13.HeaderText = "ID";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            // 
            // Column15
            // 
            this.Column15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column15.DataPropertyName = "text";
            this.Column15.HeaderText = "Text";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            // 
            // Column16
            // 
            this.Column16.DataPropertyName = "sender";
            this.Column16.HeaderText = "Sender";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            // 
            // Column14
            // 
            this.Column14.DataPropertyName = "time";
            this.Column14.HeaderText = "Time";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.label24);
            this.tabPage11.Controls.Add(this.textBox1);
            this.tabPage11.Controls.Add(this.label23);
            this.tabPage11.Controls.Add(this.label22);
            this.tabPage11.Controls.Add(this.radioButton2);
            this.tabPage11.Controls.Add(this.button10);
            this.tabPage11.Controls.Add(this.radioButton1);
            this.tabPage11.Controls.Add(this.textBox2id);
            this.tabPage11.Controls.Add(this.textBox1message);
            this.tabPage11.Location = new System.Drawing.Point(4, 25);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(707, 337);
            this.tabPage11.TabIndex = 2;
            this.tabPage11.Text = "发送消息";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(111, 245);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(23, 15);
            this.label24.TabIndex = 8;
            this.label24.Text = "id";
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(190, 235);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(339, 25);
            this.textBox1.TabIndex = 7;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(97, 191);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(52, 15);
            this.label23.TabIndex = 6;
            this.label23.Text = "发送至";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(97, 41);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(52, 15);
            this.label22.TabIndex = 5;
            this.label22.Text = "内容：";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(380, 160);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(88, 19);
            this.radioButton2.TabIndex = 4;
            this.radioButton2.Text = "全部用户";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(297, 275);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(87, 33);
            this.button10.TabIndex = 3;
            this.button10.Text = "发送";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(203, 160);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(88, 19);
            this.radioButton1.TabIndex = 2;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "单个用户";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // textBox2id
            // 
            this.textBox2id.Location = new System.Drawing.Point(190, 191);
            this.textBox2id.Name = "textBox2id";
            this.textBox2id.Size = new System.Drawing.Size(339, 25);
            this.textBox2id.TabIndex = 1;
            // 
            // textBox1message
            // 
            this.textBox1message.Location = new System.Drawing.Point(190, 38);
            this.textBox1message.Multiline = true;
            this.textBox1message.Name = "textBox1message";
            this.textBox1message.Size = new System.Drawing.Size(339, 98);
            this.textBox1message.TabIndex = 0;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(0, 356);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(194, 66);
            this.button6.TabIndex = 17;
            this.button6.Text = "图书管理";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // tushuyilan
            // 
            this.tushuyilan.Controls.Add(this.dataGridView111222);
            this.tushuyilan.Location = new System.Drawing.Point(200, 42);
            this.tushuyilan.Name = "tushuyilan";
            this.tushuyilan.Size = new System.Drawing.Size(726, 380);
            this.tushuyilan.TabIndex = 18;
            this.tushuyilan.TabStop = false;
            // 
            // dataGridView111222
            // 
            this.dataGridView111222.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView111222.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column10,
            this.Column11,
            this.Column12});
            this.dataGridView111222.Location = new System.Drawing.Point(0, 5);
            this.dataGridView111222.Name = "dataGridView111222";
            this.dataGridView111222.RowTemplate.Height = 27;
            this.dataGridView111222.Size = new System.Drawing.Size(720, 375);
            this.dataGridView111222.TabIndex = 0;
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "id";
            this.Column10.HeaderText = "书号";
            this.Column10.Name = "Column10";
            // 
            // Column11
            // 
            this.Column11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column11.DataPropertyName = "bname";
            this.Column11.HeaderText = "书名";
            this.Column11.Name = "Column11";
            // 
            // Column12
            // 
            this.Column12.DataPropertyName = "bnum";
            this.Column12.HeaderText = "数量";
            this.Column12.Name = "Column12";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 15;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2radiocheck
            // 
            this.timer2radiocheck.Enabled = true;
            this.timer2radiocheck.Interval = 20;
            this.timer2radiocheck.Tick += new System.EventHandler(this.timer2radiocheck_Tick);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.button3qvxiaojingxuan);
            this.tabPage4.Controls.Add(this.dataGridView2jingxuanliuyan);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(784, 340);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "精选留言";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // button3qvxiaojingxuan
            // 
            this.button3qvxiaojingxuan.Location = new System.Drawing.Point(333, 307);
            this.button3qvxiaojingxuan.Name = "button3qvxiaojingxuan";
            this.button3qvxiaojingxuan.Size = new System.Drawing.Size(103, 32);
            this.button3qvxiaojingxuan.TabIndex = 3;
            this.button3qvxiaojingxuan.Text = "取消精选";
            this.button3qvxiaojingxuan.UseVisualStyleBackColor = true;
            this.button3qvxiaojingxuan.Click += new System.EventHandler(this.button3qvxiaojingxuan_Click);
            // 
            // dataGridView2jingxuanliuyan
            // 
            this.dataGridView2jingxuanliuyan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2jingxuanliuyan.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView2jingxuanliuyan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2jingxuanliuyan.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.dataGridView2jingxuanliuyan.Location = new System.Drawing.Point(6, 6);
            this.dataGridView2jingxuanliuyan.Name = "dataGridView2jingxuanliuyan";
            this.dataGridView2jingxuanliuyan.RowTemplate.Height = 27;
            this.dataGridView2jingxuanliuyan.Size = new System.Drawing.Size(699, 295);
            this.dataGridView2jingxuanliuyan.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "username";
            this.dataGridViewTextBoxColumn2.HeaderText = "用户名";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "text";
            this.dataGridViewTextBoxColumn3.HeaderText = "留言内容";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "time";
            this.dataGridViewTextBoxColumn1.HeaderText = "时间";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn4.HeaderText = "特征码";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "jx";
            this.dataGridViewTextBoxColumn5.HeaderText = "精选留言";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // duzheguanli
            // 
            this.duzheguanli.Controls.Add(this.tabControl2);
            this.duzheguanli.Location = new System.Drawing.Point(200, 42);
            this.duzheguanli.Name = "duzheguanli";
            this.duzheguanli.Size = new System.Drawing.Size(721, 380);
            this.duzheguanli.TabIndex = 16;
            this.duzheguanli.TabStop = false;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Location = new System.Drawing.Point(0, 5);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(721, 375);
            this.tabControl2.TabIndex = 1;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.groupBox1);
            this.tabPage7.Controls.Add(this.button12);
            this.tabPage7.Controls.Add(this.label12);
            this.tabPage7.Controls.Add(this.label13);
            this.tabPage7.Controls.Add(this.textBox11duzheming);
            this.tabPage7.Controls.Add(this.textBox10duzhenianling);
            this.tabPage7.Controls.Add(this.button5chaxun);
            this.tabPage7.Controls.Add(this.dataGridView1);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(713, 346);
            this.tabPage7.TabIndex = 0;
            this.tabPage7.Text = "读者信息";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.button14);
            this.groupBox1.Controls.Add(this.button13);
            this.groupBox1.Controls.Add(this.textBox22);
            this.groupBox1.Controls.Add(this.textBox11);
            this.groupBox1.Location = new System.Drawing.Point(221, 63);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(235, 250);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "添加用户";
            this.groupBox1.Visible = false;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(19, 128);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(37, 15);
            this.label26.TabIndex = 5;
            this.label26.Text = "密码";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(19, 34);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(52, 15);
            this.label25.TabIndex = 4;
            this.label25.Text = "用户名";
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(128, 204);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(101, 40);
            this.button14.TabIndex = 3;
            this.button14.Text = "返回";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(9, 204);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(101, 40);
            this.button13.TabIndex = 2;
            this.button13.Text = "添加用户";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(53, 158);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(139, 25);
            this.textBox22.TabIndex = 1;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(53, 63);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(139, 25);
            this.textBox11.TabIndex = 0;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(631, 7);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(79, 38);
            this.button12.TabIndex = 11;
            this.button12.Text = "添加";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(20, 18);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 15);
            this.label12.TabIndex = 9;
            this.label12.Text = "用户名:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(271, 18);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(45, 15);
            this.label13.TabIndex = 8;
            this.label13.Text = "年龄:";
            // 
            // textBox11duzheming
            // 
            this.textBox11duzheming.Location = new System.Drawing.Point(77, 12);
            this.textBox11duzheming.Name = "textBox11duzheming";
            this.textBox11duzheming.Size = new System.Drawing.Size(100, 25);
            this.textBox11duzheming.TabIndex = 7;
            this.textBox11duzheming.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox10duzhenianling
            // 
            this.textBox10duzhenianling.Location = new System.Drawing.Point(313, 12);
            this.textBox10duzhenianling.Name = "textBox10duzhenianling";
            this.textBox10duzhenianling.Size = new System.Drawing.Size(100, 25);
            this.textBox10duzhenianling.TabIndex = 6;
            this.textBox10duzhenianling.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button5chaxun
            // 
            this.button5chaxun.Location = new System.Drawing.Point(546, 7);
            this.button5chaxun.Name = "button5chaxun";
            this.button5chaxun.Size = new System.Drawing.Size(79, 38);
            this.button5chaxun.TabIndex = 1;
            this.button5chaxun.Text = "查询";
            this.button5chaxun.UseVisualStyleBackColor = true;
            this.button5chaxun.Click += new System.EventHandler(this.button5chaxun_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            this.dataGridView1.Location = new System.Drawing.Point(3, 50);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 27;
            this.dataGridView1.Size = new System.Drawing.Size(704, 293);
            this.dataGridView1.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn8.DataPropertyName = "username";
            this.dataGridViewTextBoxColumn8.HeaderText = "用户名";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn9.DataPropertyName = "password";
            this.dataGridViewTextBoxColumn9.HeaderText = "密码";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "age";
            this.dataGridViewTextBoxColumn10.HeaderText = "年龄";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "sex";
            this.dataGridViewTextBoxColumn11.HeaderText = "性别";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn12.DataPropertyName = "qq";
            this.dataGridViewTextBoxColumn12.HeaderText = "QQ";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.读者信息修改);
            this.tabPage8.Controls.Add(this.button4duzheqq);
            this.tabPage8.Controls.Add(this.button3duzhemnian);
            this.tabPage8.Controls.Add(this.button2duzhexing);
            this.tabPage8.Controls.Add(this.button1duzhemi);
            this.tabPage8.Controls.Add(this.textBox5duzheqq);
            this.tabPage8.Controls.Add(this.textBox4duzhenian);
            this.tabPage8.Controls.Add(this.textBox3duzhexing);
            this.tabPage8.Controls.Add(this.textBox2duzhemi);
            this.tabPage8.Controls.Add(this.textBox1duzheming);
            this.tabPage8.Controls.Add(this.label14);
            this.tabPage8.Controls.Add(this.label15);
            this.tabPage8.Controls.Add(this.label16);
            this.tabPage8.Controls.Add(this.label17);
            this.tabPage8.Controls.Add(this.label18);
            this.tabPage8.Location = new System.Drawing.Point(4, 25);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(713, 346);
            this.tabPage8.TabIndex = 1;
            this.tabPage8.Text = "管理信息";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // 读者信息修改
            // 
            this.读者信息修改.AutoSize = true;
            this.读者信息修改.Font = new System.Drawing.Font("楷体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.读者信息修改.Location = new System.Drawing.Point(287, 33);
            this.读者信息修改.Name = "读者信息修改";
            this.读者信息修改.Size = new System.Drawing.Size(160, 24);
            this.读者信息修改.TabIndex = 14;
            this.读者信息修改.Text = "读者信息修改";
            // 
            // button4duzheqq
            // 
            this.button4duzheqq.Location = new System.Drawing.Point(474, 262);
            this.button4duzheqq.Name = "button4duzheqq";
            this.button4duzheqq.Size = new System.Drawing.Size(75, 31);
            this.button4duzheqq.TabIndex = 13;
            this.button4duzheqq.Text = "修改";
            this.button4duzheqq.UseVisualStyleBackColor = true;
            this.button4duzheqq.Click += new System.EventHandler(this.button4duzheqq_Click);
            // 
            // button3duzhemnian
            // 
            this.button3duzhemnian.Location = new System.Drawing.Point(474, 216);
            this.button3duzhemnian.Name = "button3duzhemnian";
            this.button3duzhemnian.Size = new System.Drawing.Size(75, 33);
            this.button3duzhemnian.TabIndex = 12;
            this.button3duzhemnian.Text = "修改";
            this.button3duzhemnian.UseVisualStyleBackColor = true;
            this.button3duzhemnian.Click += new System.EventHandler(this.button3duzhemnian_Click);
            // 
            // button2duzhexing
            // 
            this.button2duzhexing.Location = new System.Drawing.Point(474, 171);
            this.button2duzhexing.Name = "button2duzhexing";
            this.button2duzhexing.Size = new System.Drawing.Size(75, 33);
            this.button2duzhexing.TabIndex = 11;
            this.button2duzhexing.Text = "修改";
            this.button2duzhexing.UseVisualStyleBackColor = true;
            this.button2duzhexing.Click += new System.EventHandler(this.button2duzhexing_Click);
            // 
            // button1duzhemi
            // 
            this.button1duzhemi.Location = new System.Drawing.Point(474, 130);
            this.button1duzhemi.Name = "button1duzhemi";
            this.button1duzhemi.Size = new System.Drawing.Size(75, 33);
            this.button1duzhemi.TabIndex = 10;
            this.button1duzhemi.Text = "修改";
            this.button1duzhemi.UseVisualStyleBackColor = true;
            this.button1duzhemi.Click += new System.EventHandler(this.button1duzhemi_Click);
            // 
            // textBox5duzheqq
            // 
            this.textBox5duzheqq.Location = new System.Drawing.Point(262, 268);
            this.textBox5duzheqq.Name = "textBox5duzheqq";
            this.textBox5duzheqq.Size = new System.Drawing.Size(161, 25);
            this.textBox5duzheqq.TabIndex = 9;
            this.textBox5duzheqq.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4duzhenian
            // 
            this.textBox4duzhenian.Location = new System.Drawing.Point(262, 225);
            this.textBox4duzhenian.Name = "textBox4duzhenian";
            this.textBox4duzhenian.Size = new System.Drawing.Size(161, 25);
            this.textBox4duzhenian.TabIndex = 8;
            this.textBox4duzhenian.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3duzhexing
            // 
            this.textBox3duzhexing.Location = new System.Drawing.Point(262, 179);
            this.textBox3duzhexing.Name = "textBox3duzhexing";
            this.textBox3duzhexing.Size = new System.Drawing.Size(161, 25);
            this.textBox3duzhexing.TabIndex = 7;
            this.textBox3duzhexing.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2duzhemi
            // 
            this.textBox2duzhemi.Location = new System.Drawing.Point(262, 136);
            this.textBox2duzhemi.Name = "textBox2duzhemi";
            this.textBox2duzhemi.Size = new System.Drawing.Size(161, 25);
            this.textBox2duzhemi.TabIndex = 6;
            this.textBox2duzhemi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox1duzheming
            // 
            this.textBox1duzheming.Location = new System.Drawing.Point(262, 93);
            this.textBox1duzheming.Name = "textBox1duzheming";
            this.textBox1duzheming.Size = new System.Drawing.Size(161, 25);
            this.textBox1duzheming.TabIndex = 5;
            this.textBox1duzheming.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(169, 271);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(38, 15);
            this.label14.TabIndex = 4;
            this.label14.Text = "QQ：";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(169, 225);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(52, 15);
            this.label15.TabIndex = 3;
            this.label15.Text = "年龄：";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(169, 179);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(52, 15);
            this.label16.TabIndex = 2;
            this.label16.Text = "性别：";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(169, 136);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(52, 15);
            this.label17.TabIndex = 1;
            this.label17.Text = "密码：";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(169, 93);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(75, 15);
            this.label18.TabIndex = 0;
            this.label18.Text = "用户名*：";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.button6shensutongyi);
            this.tabPage6.Controls.Add(this.label11);
            this.tabPage6.Controls.Add(this.dataGridView2zhanghaoshensu);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(713, 346);
            this.tabPage6.TabIndex = 2;
            this.tabPage6.Text = "账号申诉";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // button6shensutongyi
            // 
            this.button6shensutongyi.Location = new System.Drawing.Point(286, 293);
            this.button6shensutongyi.Name = "button6shensutongyi";
            this.button6shensutongyi.Size = new System.Drawing.Size(139, 42);
            this.button6shensutongyi.TabIndex = 2;
            this.button6shensutongyi.Text = "同意";
            this.button6shensutongyi.UseVisualStyleBackColor = true;
            this.button6shensutongyi.Click += new System.EventHandler(this.button6shensutongyi_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 8);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 15);
            this.label11.TabIndex = 1;
            this.label11.Text = "申诉信息";
            // 
            // dataGridView2zhanghaoshensu
            // 
            this.dataGridView2zhanghaoshensu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2zhanghaoshensu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column9,
            this.Column8,
            this.Column6,
            this.Column7});
            this.dataGridView2zhanghaoshensu.Location = new System.Drawing.Point(6, 35);
            this.dataGridView2zhanghaoshensu.Name = "dataGridView2zhanghaoshensu";
            this.dataGridView2zhanghaoshensu.RowTemplate.Height = 27;
            this.dataGridView2zhanghaoshensu.Size = new System.Drawing.Size(701, 252);
            this.dataGridView2zhanghaoshensu.TabIndex = 0;
            // 
            // Column9
            // 
            this.Column9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column9.DataPropertyName = "username";
            this.Column9.HeaderText = "用户名";
            this.Column9.Name = "Column9";
            // 
            // Column8
            // 
            this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column8.DataPropertyName = "time";
            this.Column8.HeaderText = "申诉时间";
            this.Column8.Name = "Column8";
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "id";
            this.Column6.HeaderText = "特征码";
            this.Column6.Name = "Column6";
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "flag";
            this.Column7.HeaderText = "操作";
            this.Column7.Name = "Column7";
            // 
            // liuyanguanli
            // 
            this.liuyanguanli.Controls.Add(this.tabControl1);
            this.liuyanguanli.Location = new System.Drawing.Point(200, 47);
            this.liuyanguanli.Name = "liuyanguanli";
            this.liuyanguanli.Size = new System.Drawing.Size(721, 375);
            this.liuyanguanli.TabIndex = 16;
            this.liuyanguanli.TabStop = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(6, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(792, 369);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.button2jingxuanliuyan);
            this.tabPage5.Controls.Add(this.button1shanchuliuyan);
            this.tabPage5.Controls.Add(this.dataGridView1chakanliuyan);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(784, 340);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "留言管理";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // button2jingxuanliuyan
            // 
            this.button2jingxuanliuyan.Location = new System.Drawing.Point(532, 296);
            this.button2jingxuanliuyan.Name = "button2jingxuanliuyan";
            this.button2jingxuanliuyan.Size = new System.Drawing.Size(92, 43);
            this.button2jingxuanliuyan.TabIndex = 2;
            this.button2jingxuanliuyan.Text = "精选";
            this.button2jingxuanliuyan.UseVisualStyleBackColor = true;
            this.button2jingxuanliuyan.Click += new System.EventHandler(this.button2jingxuanliuyan_Click);
            // 
            // button1shanchuliuyan
            // 
            this.button1shanchuliuyan.Location = new System.Drawing.Point(106, 296);
            this.button1shanchuliuyan.Name = "button1shanchuliuyan";
            this.button1shanchuliuyan.Size = new System.Drawing.Size(103, 43);
            this.button1shanchuliuyan.TabIndex = 1;
            this.button1shanchuliuyan.Text = "删除";
            this.button1shanchuliuyan.UseVisualStyleBackColor = true;
            this.button1shanchuliuyan.Click += new System.EventHandler(this.button1shanchuliuyan_Click);
            // 
            // dataGridView1chakanliuyan
            // 
            this.dataGridView1chakanliuyan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1chakanliuyan.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1chakanliuyan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1chakanliuyan.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn6,
            this.Column3,
            this.Column4,
            this.Column5});
            this.dataGridView1chakanliuyan.Location = new System.Drawing.Point(6, 6);
            this.dataGridView1chakanliuyan.Name = "dataGridView1chakanliuyan";
            this.dataGridView1chakanliuyan.RowTemplate.Height = 27;
            this.dataGridView1chakanliuyan.Size = new System.Drawing.Size(699, 284);
            this.dataGridView1chakanliuyan.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "time";
            this.dataGridViewTextBoxColumn7.HeaderText = "时间";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "username";
            this.dataGridViewTextBoxColumn6.HeaderText = "用户名";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "text";
            this.Column3.HeaderText = "留言内容";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "id";
            this.Column4.HeaderText = "特征码";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "jx";
            this.Column5.HeaderText = "精选留言";
            this.Column5.Name = "Column5";
            // 
            // MainForm_admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(927, 424);
            this.Controls.Add(this.duzheguanli);
            this.Controls.Add(this.tushuguanli);
            this.Controls.Add(this.xiaoxiguanli);
            this.Controls.Add(this.liuyanguanli);
            this.Controls.Add(this.jieyueguanli);
            this.Controls.Add(this.tushuyilan);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm_admin";
            this.Text = "图书管理系统_admin";
            this.Load += new System.EventHandler(this.MainForm_admin_Load);
            this.tushuguanli.ResumeLayout(false);
            this.图书夹.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1shanchutushuxianshi)).EndInit();
            this.jieyueguanli.ResumeLayout(false);
            this.jieyueguanli.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.xiaoxiguanli.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.tabPage11.ResumeLayout(false);
            this.tabPage11.PerformLayout();
            this.tushuyilan.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView111222)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2jingxuanliuyan)).EndInit();
            this.duzheguanli.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2zhanghaoshensu)).EndInit();
            this.liuyanguanli.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1chakanliuyan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox tushuguanli;
        private System.Windows.Forms.TabControl 图书夹;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox textBox3shuliang;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox1shuhao;
        private System.Windows.Forms.TextBox textBox2shuming;
        private System.Windows.Forms.Button button1tianjiatushu;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button3shuliangxiugai;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox4shuliang;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox5shuhao;
        private System.Windows.Forms.TextBox textBox6shuming;
        private System.Windows.Forms.Button button2shumingxiugai;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button button4shanchuanniu;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dataGridView1shanchutushuxianshi;
        private System.Windows.Forms.DataGridViewTextBoxColumn 书名;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.GroupBox jieyueguanli;
        private System.Windows.Forms.GroupBox xiaoxiguanli;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.GroupBox tushuyilan;
        private System.Windows.Forms.DataGridView dataGridView111222;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.TextBox textBox2id;
        private System.Windows.Forms.TextBox textBox1message;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Timer timer2radiocheck;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button button3qvxiaojingxuan;
        private System.Windows.Forms.DataGridView dataGridView2jingxuanliuyan;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.GroupBox duzheguanli;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox11duzheming;
        private System.Windows.Forms.TextBox textBox10duzhenianling;
        private System.Windows.Forms.Button button5chaxun;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.Label 读者信息修改;
        private System.Windows.Forms.Button button4duzheqq;
        private System.Windows.Forms.Button button3duzhemnian;
        private System.Windows.Forms.Button button2duzhexing;
        private System.Windows.Forms.Button button1duzhemi;
        private System.Windows.Forms.TextBox textBox5duzheqq;
        private System.Windows.Forms.TextBox textBox4duzhenian;
        private System.Windows.Forms.TextBox textBox3duzhexing;
        private System.Windows.Forms.TextBox textBox2duzhemi;
        private System.Windows.Forms.TextBox textBox1duzheming;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button button6shensutongyi;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dataGridView2zhanghaoshensu;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.GroupBox liuyanguanli;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button button2jingxuanliuyan;
        private System.Windows.Forms.Button button1shanchuliuyan;
        private System.Windows.Forms.DataGridView dataGridView1chakanliuyan;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
    }
}