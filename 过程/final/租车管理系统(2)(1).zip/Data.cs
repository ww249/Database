﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 租车管理系统
{
    class Data
    {
        public static string UID = "", UName = "";//登陆用户的id和姓名
    }
}
