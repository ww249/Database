﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 租车管理系统
{
    class Data
    {
        public static string UID = "", UName = "";//登陆用户的id和姓名
        public static bool flag = true;//是用户吗，用户为1，管理员为0，默认为用户

    }
}
